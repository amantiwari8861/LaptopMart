const products: Product[] = [
    {
        "id": 1,
        "title": "HP Laptop (13th Gen Intel Core i5/ 16GB RAM/ 512GB SSD/ 15.6 Inch (39.6 cm) FHD Display/ Intel Iris Xe Graphics/ Windows 11) 15-fd0577TU",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/5/251728_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 59499,
        "mrp": 76000,
        "discount": 22,
        "deliveryDate": "8th February, 2026"
    },
    {
        "id": 2,
        "title": "HP Laptop (Intel Core 3/ 8GB RAM/ 512GB SSD/ 15.6 Inch (39.6 cm) FHD Display/ Intel Graphics/ Windows 11/ MS-Office) 14-gr0006TU",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/4/245850_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 41499,
        "mrp": 47716,
        "discount": 13,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 3,
        "title": "HP Laptop (Intel Core 5/ 16GB RAM/ 512GB SSD/ 14 Inch (35.6 cm) FHD Display/ Intel Iris Xe Graphics/ Windows 11/ MS-Office) 14-gr0006TU",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/5/251005_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 61499,
        "mrp": 76768,
        "discount": 20,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 4,
        "title": "ASUS TUF A16 Gaming Laptop (AMD Ryzen 7 7445HS/ 16GB RAM/ 512GB Storage/ 16 Inch (40.64 cm) FHD+ Display/ 6GB-NVIDIA GeForce RTX 4050 Graphics/ Windows 11/ MS-Office) FA607NUG-RL136WS",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/4/249289_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 96990,
        "mrp": 112990,
        "discount": 14,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 5,
        "title": "ASUS Vivobook 15 Light Weight Laptop (13th Gen Intel Core i3/ 16GB RAM/ 512GB Storage/ 15.6 Inch (39.62 cm) FHD Display/ Intel Graphics/ Windows 11/ MS-Office) X1504VA-D5341WS",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/5/251123_2_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 42990,
        "mrp": 54990,
        "discount": 22,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 6,
        "title": "ASUS Vivobook 15 Light Weight Laptop (13th Gen Intel Core i3/ 8GB RAM/ 512GB Storage/ 15.6 Inch (39.62 cm) FHD Display/ Intel Graphics/ Windows 11/ MS-Office) X1504VA-D5321WS",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/5/251122_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 38990,
        "mrp": 50990,
        "discount": 24,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 7,
        "title": "HP Victus Gaming Laptop (14th Gen Intel Core i5/ 24GB RAM/ 512GB SSD/ 15.6 Inch (39.62 cm) FHD Display/ 6GB-NVIDIA GeForce RTX 3050 Graphics/ Windows 11/ MS-Office) 15-fa2316TX",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/5/251010_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 84499,
        "mrp": 97759,
        "discount": 14,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 8,
        "title": "HP Laptop (Intel Core 3/ 24GB RAM/ 512GB SSD/ 15.6 Inch (39.62 cm) FHD Display/ Intel Graphics/ Windows 11) 15-fd0886TU",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/5/251003_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 47999,
        "mrp": 53412,
        "discount": 10,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 9,
        "title": "HP Laptop (Intel Core Ultra 5/ 24GB RAM/ 1TB SSD/ 15.6 Inch (39.62 cm) FHD Display/ Intel Arc Graphics/ Windows 11) 15-hr1004TU",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/5/251006_2_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 76499,
        "mrp": 83034,
        "discount": 8,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 10,
        "title": "SanDisk 2TB Portable External SSD | Up to 800MB/s Read Speed | USB 3.2 Gen 2 | Rugged Design | PC & Mac Compatible (Dark Blue)",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/s/a/sandisk_portable_ssd_1__1.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 19299,
        "mrp": 34300,
        "discount": 44,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 11,
        "title": "SanDisk 1TB Portable External SSD | Up to 800MB/s Read Speed | USB 3.2 Gen 2 | Rugged Design | PC & Mac Compatible (Dark Blue)",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/s/a/sandisk_portable_ssd_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 11999,
        "mrp": 20800,
        "discount": 42,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 12,
        "title": "Apple Magic Keyboard with Numeric Keypad | Bluetooth | Rechargeable | Extended Layout | For Mac, iPad & iPhone (Silver)",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/m/q/mq052.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 10499,
        "mrp": 12500,
        "discount": 16,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 13,
        "title": "HP K280 Gaming Keyboard | RGB LED Backlit | 26-Key Anti-Ghosting | Full-Size Membrane Keys | USB Wired Gaming Keyboard (Black)",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/3/2/320049_0_jiiewng6q.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 1099,
        "mrp": 2199,
        "discount": 50,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 14,
        "title": "Asus TUF F16 Gaming Laptop (Intel Core 5/ 16GB RAM/ 512GB Storage/ 16 Inch (40.64 cm) FHD+ Display/ 6GB-NVIDIA GeForce RTX 4050 Graphics/ MS-Office/ Windows 11) FX677VU-RL055WS",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/5/251121_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 97990,
        "mrp": 108990,
        "discount": 10,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 15,
        "title": "Acer Nitro V15 ANV15-52 Gaming Laptop (13th Gen Intel Core i7/ 16GB RAM/ 512GB SSD/ 15.6 Inch (39.62 cm) FHD IPS Display/ 8GB-NVIDIA GeForce RTX 5060 Graphics/ MS-Office/ Windows 11) UN.QZASI.002",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/4/243922_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 112599,
        "mrp": 140999,
        "discount": 20,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 16,
        "title": "Dell 14 Plus 2 in 1 Laptop (Intel Core Ultra 5/ 16GB RAM/ 512GB SSD/ 14 Inch (35.6 cm) FHD+ Display/ Intel Arc Graphics/ MS-Office/ Windows 11) ODB0425020201RINU1",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/4/243560_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 93999,
        "mrp": 101999,
        "discount": 8,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 17,
        "title": "Dell WM126 Wireless Mouse | 1000 DPI Optical Tracking | 2.4GHz Wireless | USB Nano Receiver | 12-Month Battery Life | Plug & Play (Black)",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/3/236508_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 799,
        "mrp": 2299,
        "discount": 65,
        "deliveryDate": "10th February, 2026"
    },
    {
        "id": 18,
        "title": "Logitech M241 Silent Bluetooth Mouse | Wireless | Compact & Portable | 90% Reduced Click Noise | 18-Month Battery Life | Multi-OS Compatible (Off- White)",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/3/239380.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 1499,
        "mrp": 1595,
        "discount": 6,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 19,
        "title": "Logitech M241 Silent Bluetooth Mouse | Wireless | Compact & Portable | 90% Reduced Click Noise | 18-Month Battery Life | Multi-OS Compatible (Graphite)",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/3/239379_1__2.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 1499,
        "mrp": 1595,
        "discount": 6,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 20,
        "title": "Lenovo 210 Wireless Keyboard & Mouse Combo | 2.4GHz USB | Waterproof Keyboard | 1600 DPI Mouse | One-Touch Copilot Key | Adjustable Stand (Black)",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/5/250054_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 1449,
        "mrp": 2690,
        "discount": 46,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 21,
        "title": "Lenovo 120 Wired USB Mouse | 1600 DPI Optical Sensor | Plug & Play | Ergonomic Ambidextrous Design | 3-Button with Scroll Wheel (Black)",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/3/236083_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 299,
        "mrp": 490,
        "discount": 39,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 22,
        "title": "HP Laptop (AMD Ryzen 5/ 16GB RAM/ 512GB SSD/ 14 Inch (35.6 cm) FHD Display/ AMD Radeon Graphics/ Windows 11) 14-em0241AU",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/5/251004_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 49499,
        "mrp": 56831,
        "discount": 13,
        "deliveryDate": "8th February, 2026"
    },
    {
        "id": 23,
        "title": "Acer Nitro Lite NL16-71G Gaming Laptop (13th Gen Intel Core i5/ 16GB RAM/ 512GB SSD/ 16 Inch (40.64 cm) WUXGA Display/ 6GB-NVIDIA GeForce RTX 4050 Graphics/ Windows 11) UN.D5ASI.002",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/5/250814.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 72990,
        "mrp": 107799,
        "discount": 32,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 24,
        "title": "Dell DC 14250 Laptop (Intel Core 5/ 16GB RAM/ 512GB SSD/ 14 Inch (35.56 cm) Full HD+ Display/ Intel UHD Graphics/ Windows 11/ MS-Office) ODC1425000401RINS1",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/5/250797_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 65999,
        "mrp": 80000,
        "discount": 18,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 25,
        "title": "HP Laptop (Intel Core Ultra 5/ 16GB RAM/ 512GB SSD/ 15.6 Inch (39.6 cm) FHD IPS Display/ Intel Arc Graphics/ Windows 11) 15-fd1254TU",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/5/251001_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 66999,
        "mrp": 83034,
        "discount": 19,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 26,
        "title": "Dell 14 Plus Laptop (Intel Core Ultra 5/ 16GB RAM/ 512GB SSD/ 14 Inch (35.56 cm) 2.5K Display/ Intel Arc Graphics/ Windows 11/ MS-Office) ODB1425021001RINU1",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/5/251091_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 82499,
        "mrp": 83499,
        "discount": 1,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 27,
        "title": "HP Victus Gaming Laptop (AMD Ryzen 7/ 16GB RAM/ 512GB SSD/ 15.6 Inch (39.62 cm) FHD Display/ 6GB-NVIDIA GeForce RTX 4050 Graphics/ Windows 11) 15-fb3124AX",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/5/251009_1.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 89499,
        "mrp": 100019,
        "discount": 11,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 28,
        "title": "HP Victus Gaming Laptop (AMD Ryzen 7/ 16GB RAM/ 1TB SSD/ 15.6 Inch (39.62 cm) FHD Display/ 6GB-NVIDIA GeForce RTX 4050 Graphics/ Windows 11) 15-fb3162AX",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/5/251008_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 90499,
        "mrp": 102280,
        "discount": 12,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 29,
        "title": "Dell DC 15250 Laptop (13th Gen Intel Core i5/ 16GB RAM/ 1TB SSD/ 15.6 Inch (39.62 cm) FHD IPS Display/ Intel UHD Graphics/ Windows 11/ MS-Office) ODC1525001301RINS1",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/2/4/248214_1_.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 63999,
        "mrp": 79400,
        "discount": 19,
        "deliveryDate": "7th February, 2026"
    },
    {
        "id": 30,
        "title": "TP-Link UH3020C USB Type-C 3-in-1 Hub | 4K@60Hz HDMI | 100W Power Delivery | USB 3.0 Data Port | Plug & Play (Grey)",
        "image": "https://vsprod.vijaysales.com/media/catalog/product/u/h/uh3020c_un_1.0_overview_01_large_20241210015321r.jpg?optimize=medium&fit=bounds&height=250&width=250",
        "price": 1399,
        "mrp": 2799,
        "discount": 50,
        "deliveryDate": "7th February, 2026"
    }
];


import { useParams } from "react-router";
import { useMemo, useState } from "react";

/* ===========================
   TYPES
=========================== */

type Product = {
    id: number;
    title: string;
    image: string;
    price: number;
    mrp: number;
    discount: number;
    deliveryDate: string;
};

type Sentiment = "Positive" | "Negative" | "Neutral";

type Review = {
    id: number;
    title: string;
    date: string;
    rating: number;
    comment: string;
    sentiment: Sentiment;
};

/* ===========================
   STATIC REVIEWS (INITIAL)
=========================== */

const initialReviews: Review[] = [
    
];

const sentimentStyles: Record<Sentiment, string> = {
    Positive: "bg-green-100 text-green-700 border-green-300",
    Negative: "bg-red-100 text-red-700 border-red-300",
    Neutral: "bg-yellow-100 text-yellow-700 border-yellow-300",
};

/* ===========================
   MAIN COMPONENT
=========================== */

const API_URL = import.meta.env.VITE_BACKEND_API_URL;

const ProductDetails = () => {
    const { id } = useParams<{ id: string }>();

    const product = useMemo(() => {
        return products.find((p) => p.id === Number(id)) ?? null;
    }, [id]);

    const [reviews, setReviews] = useState<Review[]>(initialReviews);
    const [filter, setFilter] = useState<Sentiment | "All">("All");
    const [comment, setComment] = useState("");
    const [loading, setLoading] = useState(false);

    if (!product) return <div>Product not found</div>;

    /* ===========================
       FILTERED REVIEWS
    =========================== */

    const filteredReviews = useMemo(() => {
        if (filter === "All") return reviews;
        return reviews.filter((r) => r.sentiment === filter);
    }, [filter, reviews]);

    /* ===========================
       SUBMIT REVIEW
    =========================== */

    const handleSubmit = async () => {
        if (!comment.trim()) return;

        setLoading(true);

        try {
            const res = await fetch(API_URL + "/api/v1/analyze", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    productId: product.id,
                    comment,
                }),
            });

            const data = await res.json();

            const newReview: Review = {
                id: Date.now(),
                title: "You",
                date: new Date().toLocaleDateString(),
                rating: 5,
                comment,
                sentiment: data.sentiment as Sentiment,
            };

            setReviews((prev) => [newReview, ...prev]);
            setComment("");
        } catch (err) {
            console.error(err);
        }

        setLoading(false);
    };

    /* ===========================
       UI
    =========================== */

    return (
        <div className="max-w-6xl mx-auto p-6 grid md:grid-cols-6 gap-10">

            {/* Product Image */}
            <div className="img-container col-span-2">
                <img
                    src={product.image}
                    alt={product.title}
                    className="rounded-2xl shadow-md"
                />
                {/* Product Info */}
                {/* <p className="text-gray-600 mb-4">{id}</p> */}
                <h1 className="text-2xl font-bold mb-2">{product.title}</h1>
                <p className="text-xl font-semibold mb-6">${product.price}</p>

            </div>

            <div className="col-span-4">

                {/* Review Section */}
                <div className="mt-8">
                    {/* Filter Buttons */}
                    <div className="flex gap-3 mb-6">
                        {["All", "Positive", "Neutral", "Negative"].map((type) => (
                            <button
                                key={type}
                                onClick={() => setFilter(type as any)}
                                className={`px-4 py-2 rounded-full border text-sm font-medium transition
                  ${filter === type
                                        ? "bg-indigo-600 text-white border-indigo-600"
                                        : "bg-white text-gray-700 border-gray-300 hover:bg-gray-100"
                                    }`}
                            >
                                {type}
                            </button>
                        ))}
                    </div>

                    {/* Review List */}
                    <div className="space-y-4">
                        {filteredReviews.map((review) => (
                            <div
                                key={review.id}
                                className="p-4 border rounded-xl shadow-sm bg-white"
                            >
                                <div className="flex justify-between mb-2">
                                    <h4 className="font-semibold">{review.title}</h4>
                                    <span
                                        className={`px-2 py-1 text-xs rounded-full border ${sentimentStyles[review.sentiment]}`}
                                    >
                                        {review.sentiment}
                                    </span>
                                </div>

                                <div className="text-yellow-500 text-sm mb-2">
                                    {"★".repeat(review.rating)}
                                    {"☆".repeat(5 - review.rating)}
                                </div>

                                <p className="text-sm text-gray-600">
                                    {review.comment}
                                </p>
                            </div>
                        ))}
                    </div>
                    {/* Comment Box */}
                    <div className="my-12 flex flex-col items-center">
                        <textarea
                            value={comment}
                            onChange={(e) => setComment(e.target.value)}
                            placeholder="Write your review..."
                            className="w-full p-3 border rounded-xl focus:ring-2 focus:ring-indigo-500"
                        />
                        <button
                            onClick={handleSubmit}
                            disabled={loading}
                            className="mt-3 px-6 py-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 transition"
                        >
                            {loading ? "Analyzing..." : "Submit Review"}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProductDetails;
